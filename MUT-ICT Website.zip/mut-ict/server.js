// ============================================
// MUT ICT Department – Main Server
// Node.js + Express full-stack application
// ============================================
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

// Middleware imports
const logger = require('./middleware/logger');
const { errorHandler, notFound } = require('./middleware/errorHandler');

// Ensure required directories exist
['public/uploads/profiles', 'public/uploads/general', 'data', 'logs'].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// Initialize database (synchronous, instant)
const { initDb } = require('./models/database');
initDb();
console.log('✅ Database initialized');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Core Middleware ────────────────────────────
app.use(logger);                                         // Request logging
app.use(express.json());                                 // Parse JSON bodies
app.use(express.urlencoded({ extended: true }));         // Parse form data
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'mut-ict-secret-2025',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 1000 * 60 * 60 * 24 } // 24 hours
}));

// Attach user to every response
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// ── API Routes ─────────────────────────────────
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/courses',       require('./routes/courses'));
app.use('/api/announcements', require('./routes/announcements'));
app.use('/api/appointments',  require('./routes/appointments'));
app.use('/api/timetable',     require('./routes/timetable'));
app.use('/api/profile',       require('./routes/profile'));
app.use('/api/chat',          require('./routes/chat'));
app.use('/api/search',        require('./routes/search'));
app.use('/api/upload',        require('./routes/upload'));
app.use('/api/faculty',       require('./routes/faculty'));
app.use('/api/enquiries',     require('./routes/enquiries'));
app.use('/api/faq',           require('./routes/faq'));

// ── Frontend (SPA) ─────────────────────────────
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ── Error Handling Middleware ──────────────────
app.use(notFound);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`\n🎓 MUT ICT Department Website`);
  console.log(`🚀 Running at http://localhost:${PORT}`);
  console.log(`📋 Logs saved to ./logs/access.log\n`);
});
