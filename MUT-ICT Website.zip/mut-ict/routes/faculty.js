// ============================================
// Faculty Route – ICT Department Lecturers Only
// GET, POST, PUT, DELETE (full CRUD)
// ============================================
const express = require('express');
const router = express.Router();
const { db } = require('../models/database');
const { requireAuth, requireRole } = require('../middleware/auth');

// GET all active ICT faculty
router.get('/', (req, res) => {
  const faculty = db.findAll('faculty', { is_active: 1 }, { orderBy: [['is_hod', 'DESC'], ['name', 'ASC']] });
  res.json(faculty.map(f => ({ ...f, subjects: JSON.parse(f.subjects || '[]') })));
});

// GET single faculty member
router.get('/:id', (req, res) => {
  const member = db.findOne('faculty', { id: parseInt(req.params.id), is_active: 1 });
  if (!member) return res.status(404).json({ error: 'Faculty member not found.' });
  res.json({ ...member, subjects: JSON.parse(member.subjects || '[]') });
});

// POST – add new faculty (admin only)
router.post('/', requireRole('admin', 'staff'), (req, res) => {
  const { name, title, role, subjects, qualification, office, email, phone, is_hod } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Name and email are required.' });
  const result = db.insert('faculty', {
    name: name.trim(), title: title || 'Mr/Ms', role: role || 'Lecturer',
    subjects: JSON.stringify(Array.isArray(subjects) ? subjects : [subjects]),
    qualification: qualification || '', office: office || 'J Block',
    email: email.trim().toLowerCase(), phone: phone || '',
    is_active: 1, is_hod: is_hod ? 1 : 0
  });
  res.json({ success: true, id: result.id });
});

// PUT – update faculty (admin only)
router.put('/:id', requireRole('admin', 'staff'), (req, res) => {
  const { name, title, role, subjects, qualification, office, email, phone, is_hod } = req.body;
  db.update('faculty', { id: parseInt(req.params.id) }, {
    name, title, role,
    subjects: JSON.stringify(Array.isArray(subjects) ? subjects : [subjects]),
    qualification, office, email, phone, is_hod: is_hod ? 1 : 0
  });
  res.json({ success: true });
});

// DELETE – soft delete (admin only)
router.delete('/:id', requireRole('admin'), (req, res) => {
  db.update('faculty', { id: parseInt(req.params.id) }, { is_active: 0 });
  res.json({ success: true });
});

module.exports = router;
