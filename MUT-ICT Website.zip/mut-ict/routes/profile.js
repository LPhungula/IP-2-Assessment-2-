// ============================================
// Profile Route – View and update user profile
// ============================================
const express = require('express');
const router = express.Router();
const { db } = require('../models/database');
const { requireAuth } = require('../middleware/auth');

// GET /api/profile – get own profile
router.get('/', requireAuth, (req, res) => {
  const user = db.findOne('users', { id: req.session.user.id });
  if (!user) return res.status(404).json({ error: 'User not found.' });
  const { password_hash, ...safe } = user;
  res.json(safe);
});

// PUT /api/profile – update own profile
router.put('/', requireAuth, (req, res) => {
  const { full_name, phone, bio, department, course } = req.body;
  if (!full_name || full_name.trim().length < 2)
    return res.status(400).json({ error: 'Full name must be at least 2 characters.' });
  db.update('users', { id: req.session.user.id }, {
    full_name: full_name.trim(), phone, bio, department, course
  });
  const updated = db.findOne('users', { id: req.session.user.id });
  req.session.user = { ...req.session.user, full_name: updated.full_name, profile_picture: updated.profile_picture };
  const { password_hash, ...safe } = updated;
  res.json({ success: true, user: safe });
});

module.exports = router;
