// ============================================
// Appointments Route – Booking system
// Full CRUD: GET, POST, PATCH, DELETE
// ============================================
const express = require('express');
const router = express.Router();
const { db } = require('../models/database');
const { requireAuth, requireRole } = require('../middleware/auth');
const { validateAppointment } = require('../middleware/validate');

// GET all staff (for booking dropdown)
router.get('/staff', (req, res) => {
  const staff = db.findAll('users', { is_active: 1 })
    .filter(u => ['staff', 'admin'].includes(u.role));
  res.json(staff.map(({ password_hash, ...s }) => s));
});

// GET available slots for a staff member
router.get('/slots/:staffId', (req, res) => {
  const staffId = parseInt(req.params.staffId);
  const today = new Date().toISOString().split('T')[0];
  const slots = db.findAll('staff_slots', { staff_id: staffId, is_available: 1 })
    .filter(s => s.date >= today)
    .map(s => ({
      ...s,
      booked: db.count('appointments', { slot_id: s.id })
    }))
    .sort((a, b) => a.date.localeCompare(b.date) || a.time_start.localeCompare(b.time_start));
  res.json(slots);
});

// POST book appointment (students only)
router.post('/book', requireRole('student'), validateAppointment, (req, res) => {
  const { slot_id, reason } = req.body;
  const slot = db.findOne('staff_slots', { id: parseInt(slot_id), is_available: 1 });
  if (!slot) return res.status(400).json({ error: 'This slot is not available.' });
  const existing = db.findAll('appointments', { slot_id: parseInt(slot_id) })
    .find(a => a.status !== 'cancelled');
  if (existing) return res.status(400).json({ error: 'This slot has already been booked.' });
  const result = db.insert('appointments', {
    slot_id: parseInt(slot_id), student_id: req.session.user.id,
    reason: reason.trim(), status: 'pending'
  });
  res.json({ success: true, appointment_id: result.id });
});

// GET student's own appointments
router.get('/my', requireAuth, (req, res) => {
  const appts = db.findAll('appointments', { student_id: req.session.user.id });
  const result = appts.map(a => {
    const slot = db.findOne('staff_slots', { id: a.slot_id }) || {};
    const staff = db.findOne('users', { id: slot.staff_id }) || {};
    return { ...a, date: slot.date, time_start: slot.time_start, time_end: slot.time_end, staff_name: staff.full_name, department: staff.department };
  }).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  res.json(result);
});

// POST add availability slot (staff only)
router.post('/slots', requireRole('staff', 'admin'), (req, res) => {
  const { date, time_start, time_end, notes } = req.body;
  if (!date || !time_start || !time_end)
    return res.status(400).json({ error: 'Date, start time, and end time are required.' });
  const result = db.insert('staff_slots', {
    staff_id: req.session.user.id, date, time_start, time_end,
    notes: notes || null, is_available: 1
  });
  res.json({ success: true, slot_id: result.id });
});

// DELETE a slot (staff only)
router.delete('/slots/:id', requireRole('staff', 'admin'), (req, res) => {
  db.update('staff_slots', { id: parseInt(req.params.id), staff_id: req.session.user.id }, { is_available: 0 });
  res.json({ success: true });
});

// GET staff's bookings
router.get('/bookings', requireRole('staff', 'admin'), (req, res) => {
  const mySlots = db.findAll('staff_slots', { staff_id: req.session.user.id });
  const result = [];
  mySlots.forEach(slot => {
    db.findAll('appointments', { slot_id: slot.id }).forEach(a => {
      const student = db.findOne('users', { id: a.student_id }) || {};
      result.push({ ...a, date: slot.date, time_start: slot.time_start, time_end: slot.time_end, student_name: student.full_name, student_number: student.student_number, student_email: student.email });
    });
  });
  result.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  res.json(result);
});

// PATCH update appointment status
router.patch('/:id/status', requireRole('staff', 'admin'), (req, res) => {
  const { status } = req.body;
  if (!['confirmed', 'cancelled', 'completed'].includes(status))
    return res.status(400).json({ error: 'Invalid status.' });
  db.update('appointments', { id: parseInt(req.params.id) }, { status });
  res.json({ success: true });
});

// DELETE appointment (cancel)
router.delete('/:id', requireAuth, (req, res) => {
  db.update('appointments', { id: parseInt(req.params.id) }, { status: 'cancelled' });
  res.json({ success: true });
});

module.exports = router;
