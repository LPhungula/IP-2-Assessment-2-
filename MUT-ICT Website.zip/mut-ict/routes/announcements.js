const express = require('express');
const router = express.Router();
const { db } = require('../models/database');
const { requireRole } = require('../middleware/auth');
const { validateAnnouncement } = require('../middleware/validate');

// GET all announcements
router.get('/', (req, res) => {
  const anns = db.findAll('announcements', { is_active:1 }, { orderBy:[['is_pinned','DESC'],['created_at','DESC']], limit:20 });
  res.json(anns);
});

// POST new announcement (staff/admin)
router.post('/', requireRole('staff','admin'), validateAnnouncement, (req, res) => {
  const { title, content, category, is_pinned, expires_at } = req.body;
  const result = db.insert('announcements', { title:title.trim(), content:content.trim(), category:category||'general', author_id:req.session.user.id, is_pinned:is_pinned?1:0, is_active:1, expires_at:expires_at||null });
  res.json({ success:true, id:result.id });
});

// PUT update announcement
router.put('/:id', requireRole('staff','admin'), (req, res) => {
  const { title, content, category, is_pinned } = req.body;
  db.update('announcements', { id:parseInt(req.params.id) }, { title, content, category, is_pinned:is_pinned?1:0 });
  res.json({ success:true });
});

// DELETE announcement (soft delete)
router.delete('/:id', requireRole('staff','admin'), (req, res) => {
  db.update('announcements', { id:parseInt(req.params.id) }, { is_active:0 });
  res.json({ success:true });
});

module.exports = router;
