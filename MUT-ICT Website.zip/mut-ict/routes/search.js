// ============================================
// Smart Search Route – Predictive autocomplete
// Searches across courses, announcements, FAQ, faculty
// ============================================
const express = require('express');
const router = express.Router();
const { db } = require('../models/database');

// GET /api/search?q=query – full search results
router.get('/', (req, res) => {
  const q = (req.query.q || '').trim().toLowerCase();
  if (q.length < 2) return res.json([]);
  const results = [];
  db.findAll('courses', { is_active: 1 }).filter(c =>
    c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q)
  ).slice(0, 3).forEach(c => results.push({ type: 'course', id: c.code, title: c.name, snippet: c.description.substring(0, 100) }));
  db.findAll('announcements', { is_active: 1 }).filter(a =>
    a.title.toLowerCase().includes(q) || a.content.toLowerCase().includes(q)
  ).slice(0, 3).forEach(a => results.push({ type: 'announcement', id: a.id, title: a.title, snippet: a.content.substring(0, 100) }));
  db.findAll('faq', { is_active: 1 }).filter(f =>
    f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q) || (f.keywords || '').toLowerCase().includes(q)
  ).slice(0, 3).forEach(f => results.push({ type: 'faq', id: f.id, title: f.question, snippet: f.answer.substring(0, 100) }));
  db.findAll('faculty', { is_active: 1 }).filter(f =>
    f.name.toLowerCase().includes(q) || f.role.toLowerCase().includes(q)
  ).slice(0, 2).forEach(f => results.push({ type: 'faculty', id: f.id, title: f.name, snippet: f.role }));
  res.json(results.slice(0, 8));
});

// GET /api/search/suggest?q=query – autocomplete suggestions
router.get('/suggest', (req, res) => {
  const q = (req.query.q || '').trim().toLowerCase();
  if (!q) return res.json([]);
  const results = [];
  db.findAll('courses', { is_active: 1 }).filter(c => c.name.toLowerCase().includes(q)).slice(0, 2)
    .forEach(c => results.push({ text: c.name, type: 'course' }));
  db.findAll('faq', { is_active: 1 }).filter(f => f.question.toLowerCase().includes(q)).slice(0, 3)
    .forEach(f => results.push({ text: f.question, type: 'faq' }));
  db.findAll('faculty', { is_active: 1 }).filter(f => f.name.toLowerCase().includes(q)).slice(0, 2)
    .forEach(f => results.push({ text: f.name, type: 'faculty' }));
  const terms = ['admission requirements', 'timetable', 'book appointment', 'ECP programme', 'Advanced Diploma', 'WIL placement', 'registration deadline', 'NSFAS financial aid', 'career opportunities', 'course requirements'];
  terms.filter(t => t.toLowerCase().includes(q)).forEach(t => results.push({ text: t, type: 'suggestion' }));
  res.json(results.slice(0, 7));
});

module.exports = router;
