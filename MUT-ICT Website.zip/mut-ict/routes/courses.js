// ============================================
// Courses Route – ICT Department Programmes
// GET, POST, PUT, DELETE (full CRUD for admin)
// ============================================
const express = require('express');
const router = express.Router();
const { db } = require('../models/database');
const { requireRole } = require('../middleware/auth');

// GET all active courses
router.get('/', (req, res) => {
  const courses = db.findAll('courses', { is_active: 1 });
  res.json(courses.map(c => ({
    ...c,
    requirements: JSON.parse(c.requirements || '{}'),
    subjects: JSON.parse(c.subjects || '{}'),
    career_paths: JSON.parse(c.career_paths || '[]')
  })));
});

// GET single course by code
router.get('/:code', (req, res) => {
  const c = db.findOne('courses', { code: req.params.code, is_active: 1 });
  if (!c) return res.status(404).json({ error: 'Course not found.' });
  res.json({ ...c, requirements: JSON.parse(c.requirements || '{}'), subjects: JSON.parse(c.subjects || '{}'), career_paths: JSON.parse(c.career_paths || '[]') });
});

// PUT update course (admin only)
router.put('/:code', requireRole('admin'), (req, res) => {
  const { name, description, duration_years, aps_score } = req.body;
  db.update('courses', { code: req.params.code }, { name, description, duration_years, aps_score });
  res.json({ success: true });
});

// DELETE course (soft delete, admin only)
router.delete('/:code', requireRole('admin'), (req, res) => {
  db.update('courses', { code: req.params.code }, { is_active: 0 });
  res.json({ success: true });
});

module.exports = router;
