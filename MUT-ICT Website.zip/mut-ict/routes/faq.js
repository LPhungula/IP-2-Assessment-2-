const express = require('express');
const router = express.Router();
const { db } = require('../models/database');
const { requireRole } = require('../middleware/auth');

router.get('/', (req, res) => {
  res.json(db.findAll('faq', { is_active: 1 }));
});

router.post('/', requireRole('staff', 'admin'), (req, res) => {
  const { question, answer, category, keywords } = req.body;
  if (!question || !answer) return res.status(400).json({ error: 'Question and answer required.' });
  const result = db.insert('faq', { question, answer, category: category || 'general', keywords: keywords || '', is_active: 1 });
  res.json({ success: true, id: result.id });
});

router.put('/:id', requireRole('staff', 'admin'), (req, res) => {
  const { question, answer, category, keywords } = req.body;
  db.update('faq', { id: parseInt(req.params.id) }, { question, answer, category, keywords });
  res.json({ success: true });
});

router.delete('/:id', requireRole('staff', 'admin'), (req, res) => {
  db.update('faq', { id: parseInt(req.params.id) }, { is_active: 0 });
  res.json({ success: true });
});

module.exports = router;
