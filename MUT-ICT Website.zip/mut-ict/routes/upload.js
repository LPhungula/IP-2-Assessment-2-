// ============================================
// Upload Route – Profile pictures & image processing
// Uses jimp (pure JS, no native build needed)
// ============================================
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { db } = require('../models/database');
const { requireAuth } = require('../middleware/auth');

const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp'];
    allowed.includes(file.mimetype) ? cb(null, true) : cb(new Error('Only image files are allowed (JPEG, PNG, GIF, BMP).'));
  }
});

['public/uploads/profiles', 'public/uploads/general'].forEach(d => {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
});

// POST /api/upload/profile-picture
router.post('/profile-picture', requireAuth, upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded.' });
  try {
    const Jimp = require('jimp');
    const filename = `profile_${req.session.user.id}_${Date.now()}.jpg`;
    const outputPath = path.join(__dirname, '../public/uploads/profiles', filename);
    const img = await Jimp.read(req.file.buffer);
    await img.cover(300, 300).quality(85).writeAsync(outputPath);
    const imageUrl = `/uploads/profiles/${filename}`;
    db.update('users', { id: req.session.user.id }, { profile_picture: imageUrl });
    req.session.user.profile_picture = imageUrl;
    res.json({ success: true, url: imageUrl });
  } catch (err) {
    console.error('Profile picture error:', err.message);
    res.status(500).json({ error: 'Failed to process image. Please try a JPEG or PNG file.' });
  }
});

// POST /api/upload/image – general image with processing options
router.post('/image', requireAuth, upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded.' });
  const { width, height, quality, grayscale, rotate } = req.body;
  try {
    const Jimp = require('jimp');
    const filename = `img_${req.session.user.id}_${Date.now()}.jpg`;
    const outputPath = path.join(__dirname, '../public/uploads/general', filename);
    let img = await Jimp.read(req.file.buffer);
    if (rotate) img = img.rotate(parseInt(rotate));
    if (grayscale === 'true') img = img.grayscale();
    if (width || height) img = img.scaleToFit(width ? parseInt(width) : 9999, height ? parseInt(height) : 9999);
    await img.quality(quality ? parseInt(quality) : 85).writeAsync(outputPath);
    res.json({ success: true, url: `/uploads/general/${filename}` });
  } catch (err) {
    console.error('Image processing error:', err.message);
    res.status(500).json({ error: 'Failed to process image.' });
  }
});

// POST /api/upload/analyze – Claude Vision image analysis
router.post('/analyze', requireAuth, upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded.' });
  if (!process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY === 'your_anthropic_api_key_here') {
    return res.json({ description: 'Image analysis requires an API key. Please configure ANTHROPIC_API_KEY in your .env file.' });
  }
  try {
    const fetch = require('node-fetch');
    const base64 = req.file.buffer.toString('base64');
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 300,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: req.file.mimetype, data: base64 } },
          { type: 'text', text: 'Briefly describe this image in 2-3 sentences for an academic department website.' }
        ]}]
      })
    });
    const data = await response.json();
    res.json({ description: data.content?.[0]?.text || 'Unable to analyze image.' });
  } catch (err) {
    res.status(500).json({ error: 'Image analysis failed.' });
  }
});

module.exports = router;
