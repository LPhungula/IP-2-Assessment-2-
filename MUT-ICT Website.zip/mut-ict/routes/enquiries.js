// ============================================
// Enquiries Route – Student/Guest Contact Form
// Demonstrates POST (create) and GET (read) + admin update/delete
// ============================================
const express = require('express');
const router = express.Router();
const { db } = require('../models/database');
const { requireRole } = require('../middleware/auth');
const { validateEnquiry } = require('../middleware/validate');

// POST – submit enquiry (anyone can submit)
router.post('/', validateEnquiry, (req, res) => {
  const { name, email, subject, message, course } = req.body;
  const result = db.insert('enquiries', {
    name: name.trim(), email: email.trim().toLowerCase(),
    subject: subject.trim(), message: message.trim(),
    course: course || null, status: 'new'
  });
  res.json({ success: true, id: result.id, message: 'Your enquiry has been received. We will respond within 2 business days.' });
});

// GET all enquiries (staff/admin only)
router.get('/', requireRole('staff', 'admin'), (req, res) => {
  const enquiries = db.findAll('enquiries', null, { orderBy: [['created_at', 'DESC']] });
  res.json(enquiries);
});

// PATCH – update enquiry status (staff/admin)
router.patch('/:id', requireRole('staff', 'admin'), (req, res) => {
  const { status } = req.body;
  if (!['new', 'in-progress', 'resolved'].includes(status))
    return res.status(400).json({ error: 'Invalid status.' });
  db.update('enquiries', { id: parseInt(req.params.id) }, { status });
  res.json({ success: true });
});

// DELETE enquiry (admin only)
router.delete('/:id', requireRole('admin'), (req, res) => {
  db.delete('enquiries', { id: parseInt(req.params.id) });
  res.json({ success: true });
});

module.exports = router;
