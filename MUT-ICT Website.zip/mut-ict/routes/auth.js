// ============================================
// Auth Routes – Register, Login, Logout
// Uses validation middleware
// ============================================
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { db } = require('../models/database');
const { requireAuth } = require('../middleware/auth');
const { validateRegistration } = require('../middleware/validate');

// POST /api/auth/register
router.post('/register', validateRegistration, async (req, res) => {
  const { full_name, email, password, role, student_number, staff_number, course, department, phone } = req.body;

  if (db.findOne('users', { email }))
    return res.status(400).json({ error: 'An account with this email already exists.' });

  try {
    const password_hash = await bcrypt.hash(password, 12);
    const result = db.insert('users', {
      full_name, email, password_hash, role,
      student_number: student_number || null,
      staff_number: staff_number || null,
      course: course || null,
      department: department || 'ICT Department',
      phone: phone || null,
      is_active: 1, profile_picture: null, bio: null
    });
    const user = db.findOne('users', { id: result.id });
    const sessionUser = { id:user.id, full_name:user.full_name, email:user.email, role:user.role, student_number:user.student_number, staff_number:user.staff_number, course:user.course, department:user.department, profile_picture:user.profile_picture };
    req.session.user = sessionUser;
    res.json({ success: true, user: sessionUser });
  } catch(err) {
    console.error(err);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });

  const user = db.findOne('users', { email: email.toLowerCase().trim(), is_active: 1 });
  if (!user) return res.status(401).json({ error: 'Invalid email or password.' });

  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) return res.status(401).json({ error: 'Invalid email or password.' });

  const sessionUser = { id:user.id, full_name:user.full_name, email:user.email, role:user.role, student_number:user.student_number, staff_number:user.staff_number, course:user.course, department:user.department, profile_picture:user.profile_picture };
  req.session.user = sessionUser;
  res.json({ success: true, user: sessionUser });
});

// POST /api/auth/logout
router.post('/logout', (req, res) => { req.session.destroy(); res.json({ success: true }); });

// GET /api/auth/me
router.get('/me', requireAuth, (req, res) => res.json({ user: req.session.user }));

module.exports = router;
