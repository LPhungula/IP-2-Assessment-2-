// ============================================
// Timetable Route – Per course, year, semester
// ============================================
const express = require('express');
const router = express.Router();
const { db } = require('../models/database');
const { requireRole } = require('../middleware/auth');

const DAY_ORDER = ['Monday','Tuesday','Wednesday','Thursday','Friday'];

// GET timetable for a course
router.get('/:courseCode', (req, res) => {
  const { courseCode } = req.params;
  const { year, semester } = req.query;
  let rows = db.findAll('timetables', { course_code: courseCode });
  if (year) rows = rows.filter(r => r.year_of_study == year);
  if (semester) rows = rows.filter(r => r.semester == semester);
  rows.sort((a, b) => {
    const di = DAY_ORDER.indexOf(a.day) - DAY_ORDER.indexOf(b.day);
    return di !== 0 ? di : a.time_start.localeCompare(b.time_start);
  });
  res.json(rows);
});

// POST add timetable entry (staff/admin)
router.post('/', requireRole('staff', 'admin'), (req, res) => {
  const { course_code, year_of_study, day, time_start, time_end, subject, venue, lecturer, semester } = req.body;
  if (!course_code || !day || !subject) return res.status(400).json({ error: 'course_code, day and subject are required.' });
  const result = db.insert('timetables', { course_code, year_of_study: parseInt(year_of_study) || 1, day, time_start, time_end, subject, venue: venue || '', lecturer: lecturer || '', semester: parseInt(semester) || 1 });
  res.json({ success: true, id: result.id });
});

// DELETE timetable entry (admin)
router.delete('/:id', requireRole('admin'), (req, res) => {
  db.delete('timetables', { id: parseInt(req.params.id) });
  res.json({ success: true });
});

module.exports = router;
