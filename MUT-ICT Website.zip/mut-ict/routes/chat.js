// ============================================
// Chat Route – Lexi AI Chatbot (Claude-powered)
// Smart offline fallback when no API key
// ============================================
const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');

const SYSTEM_PROMPT = `You are Lexi, the friendly virtual assistant for the ICT Department at Mangosuthu University of Technology (MUT) in Umlazi, Durban, South Africa.

PERSONA: Warm, professional, encouraging. Speak clear English. Occasionally use "lekker" or "sharp" naturally. Be supportive to students — many are first-generation university students.

YOU KNOW ABOUT:
- 3 ICT courses: National Diploma (3yr, mainstream, APS 18+), ECP Extended Diploma (4yr, APS 15+), Advanced Diploma (1yr post-diploma)
- Admission requirements and APS scores
- Work-Integrated Learning (WIL) — mandatory 12-month industry placement in final year
- How to book appointments: log in → Appointments → select staff → choose slot → give reason
- Department location: J Block (Technology Building), Room J201, MUT Umlazi Campus
- Office hours: Monday–Friday, 08:00–16:00
- Contact: ict@mut.ac.za | 031-907-7111
- ICT lecturers: Mr X Piyose (Internet Programming), Ms N Dlamini (HOD), Mr S Mthembu (Databases), Ms T Khumalo (Networking), Mr P Ramdeyal (Computer Systems), Ms Z Nkosi (WIL Coordinator)
- Career opportunities for ICT graduates

STUDENT SUPPORT:
- Struggling academically → Encourage, suggest peer tutoring, office hours
- Overwhelmed/stressed → Empathize, mention Student Counselling Unit
- Considering dropping out → Be supportive, suggest speaking to the HOD (Ms N Dlamini)

REFER TO DEPARTMENT (don't answer yourself):
- Specific exam timetables → "Check the MUT portal at ienabler.mut.ac.za or the departmental noticeboard"
- Individual marks/results → "Access via iEnabler or speak to your lecturer directly"
- Financial aid/NSFAS → "Contact the MUT Financial Aid Office at financialaid@mut.ac.za"
- Disciplinary matters → "Please contact the HOD's office directly"

RULES:
- Keep responses concise (2–4 sentences max unless more detail is needed)
- If unsure, say: "I'm not certain — please contact us at ict@mut.ac.za or call 031-907-7111"
- Never make up specific facts
- Always be warm and encouraging`;

// Smart offline fallback responses
function offlineReply(message) {
  const msg = message.toLowerCase();
  if (msg.includes('ecp') || msg.includes('extended')) return "The ECP (Extended Curriculum Programme) is a 4-year version of the standard 3-year National Diploma. It includes a foundational first year and is ideal for students who need extra academic support. The minimum APS is 15. Click 'Courses' on the home page to see full details!";
  if (msg.includes('advanced diploma')) return "The Advanced Diploma is a 1-year post-diploma qualification for students who have already completed the National Diploma with at least 60% average. It covers Cloud Computing, Cybersecurity, AI, and more. Check the Courses page for full requirements.";
  if (msg.includes('course') || msg.includes('diploma') || msg.includes('programme')) return "The ICT Department offers 3 programmes: **National Diploma** (3 years, APS 18+), **ECP Extended Diploma** (4 years, APS 15+), and **Advanced Diploma** (1 year, post-diploma). Click any course card on the home page for full details including requirements and subjects!";
  if (msg.includes('appoint') || msg.includes('book') || msg.includes('meet') || msg.includes('see a lecturer')) return "To book an appointment: log in as a student → go to the Appointments page → select a staff member → choose an available time slot → provide a reason. Your booking will be confirmed once the lecturer approves it.";
  if (msg.includes('apply') || msg.includes('admission') || msg.includes('register') || msg.includes('how to get in')) return "Apply through the MUT admissions office or at www.mut.ac.za/admissions. You'll need your ID, matric results, and proof of the application fee. For the mainstream Diploma you need Mathematics (40%+), English (40%+), and an APS of at least 18.";
  if (msg.includes('where') || msg.includes('location') || msg.includes('find') || msg.includes('office')) return "The ICT Department is in **J Block (Technology Building)**, Room J201, on the MUT main campus in Umlazi, Durban. Office hours are Monday–Friday, 08:00–16:00. You can also email ict@mut.ac.za or call 031-907-7111.";
  if (msg.includes('wil') || msg.includes('work integrated') || msg.includes('placement') || msg.includes('internship')) return "WIL (Work-Integrated Learning) is a mandatory 12-month industry placement in your final year. Contact Ms Z Nkosi (WIL Coordinator) at znkosi@mut.ac.za for placement information. You can also book an appointment with her through the Appointments page.";
  if (msg.includes('nsfas') || msg.includes('financial') || msg.includes('fee') || msg.includes('funding') || msg.includes('bursary')) return "For financial aid and NSFAS queries, please contact the **MUT Financial Aid Office** at financialaid@mut.ac.za or visit the Administration Building. The ICT Department cannot process financial aid applications.";
  if (msg.includes('result') || msg.includes('mark') || msg.includes('grade') || msg.includes('pass')) return "Student results are available on the MUT iEnabler portal at ienabler.mut.ac.za. If you have issues accessing your results, contact the Registrar's office. For queries about specific subject marks, speak to your lecturer directly.";
  if (msg.includes('lecturer') || msg.includes('staff') || msg.includes('teacher') || msg.includes('faculty')) return "The ICT Department has 6 dedicated lecturers including Ms N Dlamini (HOD), Mr X Piyose (Internet Programming), Mr S Mthembu (Databases), Ms T Khumalo (Networking), Mr P Ramdeyal (Computer Systems), and Ms Z Nkosi (WIL). Visit the Faculty page to see full profiles and contact details!";
  if (msg.includes('aps') || msg.includes('requirement') || msg.includes('minimum')) return "Entry requirements: **Mainstream Diploma** – APS 18+, Maths 40%+, English 40%+. **ECP** – APS 15+, Maths 30%+, English 40%+. **Advanced Diploma** – Completed National Diploma with 60%+ average. Click a course on the Courses page for the full detailed requirements.";
  if (msg.includes('hi') || msg.includes('hello') || msg.includes('hey') || msg.includes('good')) return "Hi there! 👋 I'm **Lexi**, your MUT ICT Department assistant. I'm here to help with courses, admission, appointments, and anything else about the department. What would you like to know?";
  return "Thanks for your question! I'm Lexi, the MUT ICT assistant. For the best answer, please contact the department directly at **ict@mut.ac.za** or call **031-907-7111**. You can also visit us at J Block, Room J201 during office hours (Mon–Fri, 08:00–16:00). 😊";
}

router.post('/message', async (req, res) => {
  const { message, history = [] } = req.body;
  if (!message) return res.status(400).json({ error: 'Message is required.' });

  // Use offline fallback if no API key configured
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey || apiKey === 'your_anthropic_api_key_here') {
    return res.json({ reply: offlineReply(message) });
  }

  try {
    const messages = [...history.slice(-10), { role: 'user', content: message }];
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 500, system: SYSTEM_PROMPT, messages })
    });
    const data = await response.json();
    res.json({ reply: data.content?.[0]?.text || "Sorry, I couldn't respond. Please try again!" });
  } catch (err) {
    console.error('Chatbot error:', err.message);
    res.json({ reply: offlineReply(message) });
  }
});

module.exports = router;
