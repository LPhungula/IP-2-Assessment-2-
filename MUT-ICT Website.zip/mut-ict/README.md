# 🎓 MUT ICT Department Website
### Internet Programming 2 – Assessment 2 | ITPR300/ITNP300
**Mangosuthu University of Technology | ICT Department | Umlazi, Durban**

---

## 📋 Assessment Compliance

| Requirement | Status | Implementation |
|---|---|---|
| Full-stack (HTML/CSS/JS + Node.js + Express) | ✅ | `server.js`, `public/`, `routes/` |
| Database (CRUD operations) | ✅ | JSON database, all tables with create/read/update/delete |
| Middleware (logging, auth, validation, errors) | ✅ | `middleware/` — 4 middleware files |
| AI / Smart feature | ✅ | Lexi chatbot (Claude API) + smart search |
| GET, POST, PUT/PATCH, DELETE routes | ✅ | All HTTP methods across 12 route files |
| UXD Design principles | ✅ | Responsive, accessible, MUT brand colors |
| Frontend interactivity (JavaScript) | ✅ | Modals, search, forms, filtering, tabs |
| GitHub-ready structure | ✅ | Clean file structure, `.gitignore`, README |

---

## 🚀 Quick Start

### Prerequisites
- [Node.js](https://nodejs.org) v18 or later
- [VS Code](https://code.visualstudio.com)

### Installation

```bash
# 1. Open the mut-ict folder in VS Code terminal
cd mut-ict

# 2. Install dependencies (no C++ compiler needed — pure JavaScript)
npm install

# 3. Configure environment (optional — app works without API key)
# Open .env and add your Anthropic API key for the full AI chatbot:
# ANTHROPIC_API_KEY=sk-ant-xxxxxxxx

# 4. Start the server
npm start

# 5. Open in browser
# http://localhost:3000
```

You should see:
```
✅ Database initialized
🎓 MUT ICT Department Website
🚀 Running at http://localhost:3000
📋 Logs saved to ./logs/access.log
```

---

## 📁 Project Structure

```
mut-ict/
├── server.js                  ← Express server entry point
├── package.json               ← Dependencies & scripts
├── .env                       ← Environment variables
├── .gitignore
│
├── middleware/
│   ├── auth.js                ← requireAuth, requireRole (route protection)
│   ├── logger.js              ← HTTP request logger (console + file)
│   ├── validate.js            ← Input validation (registration, announcements, appointments, enquiries)
│   └── errorHandler.js        ← Global error handler + 404 handler
│
├── models/
│   └── database.js            ← JSON file database (CRUD engine, seeding)
│
├── routes/
│   ├── auth.js                ← POST /register, POST /login, POST /logout, GET /me
│   ├── courses.js             ← GET /courses, GET /courses/:code, PUT, DELETE
│   ├── announcements.js       ← GET, POST, PUT, DELETE announcements
│   ├── appointments.js        ← Full booking system: slots, bookings, status updates
│   ├── timetable.js           ← GET timetable per course/year/semester, POST, DELETE
│   ├── profile.js             ← GET and PUT user profile
│   ├── faculty.js             ← Full CRUD for ICT lecturers
│   ├── enquiries.js           ← POST enquiry, GET (staff), PATCH status, DELETE
│   ├── faq.js                 ← GET, POST, PUT, DELETE FAQ items
│   ├── chat.js                ← AI chatbot (Claude API + smart offline fallback)
│   ├── search.js              ← Smart search + autocomplete suggestions
│   └── upload.js              ← Profile picture + image processing (resize, rotate, grayscale)
│
├── public/
│   ├── index.html             ← Single-page application (all pages)
│   ├── css/
│   │   └── styles.css         ← MUT brand styles (Blue #003580, Gold #FFD100, Maroon #800000)
│   ├── js/
│   │   └── app.js             ← Frontend JavaScript (navigation, forms, chatbot, search)
│   └── uploads/               ← User-uploaded images (auto-created)
│
├── data/
│   └── mut_ict.json           ← Database file (auto-created and seeded on first run)
│
└── logs/
    └── access.log             ← HTTP request log (auto-created)
```

---

## 👥 User Roles

| Role | Access | Unique Features |
|---|---|---|
| **Guest** | Browse all public content, use chatbot | Prompted to register when booking |
| **Student** | Everything + book appointments, view timetable | Requires student number on register |
| **Staff** | Everything + manage slots, post announcements, view enquiries | Requires staff number on register |
| **Admin** | Full access including delete operations | Set via database |

---

## 🗄️ Database Design

The system uses a JSON file database (`data/mut_ict.json`) with these tables:

| Table | Purpose | Operations |
|---|---|---|
| `users` | Students, staff, guests | C, R, U |
| `courses` | 3 ICT programmes | C, R, U, D |
| `announcements` | Department notices | C, R, U, D |
| `timetables` | Course schedules | C, R, D |
| `staff_slots` | Appointment availability | C, R, U |
| `appointments` | Bookings | C, R, U, D |
| `faculty` | ICT lecturers | C, R, U, D |
| `enquiries` | Student/guest contact form | C, R, U, D |
| `faq` | Frequently asked questions | C, R, U, D |

---

## 🔧 Middleware Explained

| Middleware | File | Purpose | Where Applied |
|---|---|---|---|
| **Logger** | `middleware/logger.js` | Logs every HTTP request (method, URL, status, time) to console and `logs/access.log` | Global — `app.use(logger)` in `server.js` |
| **Auth** | `middleware/auth.js` | `requireAuth` checks login; `requireRole(...roles)` checks user role | Individual routes needing protection |
| **Validation** | `middleware/validate.js` | Validates and sanitizes input (registration, announcements, appointments, enquiries) | POST routes before database operations |
| **Error Handler** | `middleware/errorHandler.js` | Catches unhandled errors, returns clean JSON; handles 404 routes | Last in `server.js` middleware chain |

---

## 🤖 AI Feature – Lexi Chatbot

Lexi is powered by the **Claude API (Anthropic)**. Features:
- Understands natural English questions about MUT ICT
- Answers questions about courses, admission, appointments, WIL, lecturers
- Provides student emotional support and study encouragement
- **Refers** financial aid, exam timetables, and marks to appropriate offices
- **Smart offline mode** — provides intelligent responses even without an API key using keyword matching

**To enable the full AI chatbot:**
1. Get a free API key at [console.anthropic.com](https://console.anthropic.com)
2. Open `.env` and set: `ANTHROPIC_API_KEY=your_key_here`
3. Restart the server

---

## 🌐 HTTP Routes Summary

```
GET    /api/courses              → All active courses
GET    /api/courses/:code        → Single course details
PUT    /api/courses/:code        → Update course (admin)
DELETE /api/courses/:code        → Soft-delete course (admin)

POST   /api/auth/register        → Create account (student/staff/guest)
POST   /api/auth/login           → Login
POST   /api/auth/logout          → Logout
GET    /api/auth/me              → Current user

GET    /api/announcements        → All announcements
POST   /api/announcements        → Create (staff)
PUT    /api/announcements/:id    → Update (staff)
DELETE /api/announcements/:id    → Delete (staff)

GET    /api/faculty              → All ICT lecturers
GET    /api/faculty/:id          → Single lecturer
POST   /api/faculty              → Add lecturer (admin)
PUT    /api/faculty/:id          → Update lecturer (admin)
DELETE /api/faculty/:id          → Remove lecturer (admin)

GET    /api/appointments/staff   → All staff members
GET    /api/appointments/slots/:staffId → Available slots
POST   /api/appointments/slots   → Add slot (staff)
DELETE /api/appointments/slots/:id → Remove slot (staff)
POST   /api/appointments/book    → Book appointment (student)
GET    /api/appointments/my      → My bookings (student)
GET    /api/appointments/bookings → All bookings (staff)
PATCH  /api/appointments/:id/status → Confirm/cancel (staff)
DELETE /api/appointments/:id     → Cancel (student)

GET    /api/timetable/:code      → Course timetable
POST   /api/timetable            → Add entry (staff)
DELETE /api/timetable/:id        → Remove entry (admin)

GET    /api/enquiries            → All enquiries (staff)
POST   /api/enquiries            → Submit enquiry (public)
PATCH  /api/enquiries/:id        → Update status (staff)
DELETE /api/enquiries/:id        → Delete (admin)

GET    /api/faq                  → All FAQ
POST   /api/faq                  → Add FAQ (staff)
PUT    /api/faq/:id              → Update FAQ (staff)
DELETE /api/faq/:id              → Delete FAQ (staff)

GET    /api/profile              → My profile
PUT    /api/profile              → Update my profile
POST   /api/upload/profile-picture → Upload profile photo
POST   /api/upload/image         → Process image (resize/rotate/grayscale)
POST   /api/chat/message         → Chat with Lexi AI
GET    /api/search/suggest       → Smart search suggestions
GET    /api/search               → Full search results
```

---

## 🎨 Design (UXD Principles Applied)

- **MUT Brand Colors**: Blue `#003580` | Gold `#FFD100` | Maroon `#800000`
- **Tricolor top bar** representing the three brand colors
- **Responsive layout** — works on mobile, tablet, and desktop
- **Consistent navigation** with active page highlighting
- **Feedback messages** — toast notifications for all actions
- **Modal windows** for course details and faculty profiles
- **Form validation** with clear error messages
- **Accessible** — semantic HTML, color contrast, readable typography

---

## 📬 Submission

**Lecturer GitHub:** xpiyose | xpiyose@gmail.com  
**Due:** 13 May 2026 (midnight)  
**Department:** Information and Communication Technology  
**Subject:** Internet Programming 2 (ITPR300/ITNP300)

---

*Built with Node.js, Express, Vanilla JS, and Claude AI*
