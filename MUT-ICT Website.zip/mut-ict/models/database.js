// ============================================
// MUT ICT Department - JSON Database
// Pure JavaScript - no native build required
// Supports full CRUD operations
// ============================================
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || './data/mut_ict.json';
if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });

let store = {
  users: [], courses: [], announcements: [], timetables: [],
  staff_slots: [], appointments: [], faq: [], enquiries: [], faculty: [],
  _counters: {}
};

function saveDb() {
  fs.writeFileSync(DB_PATH, JSON.stringify(store, null, 2));
}
function loadDb() {
  if (fs.existsSync(DB_PATH)) {
    try { store = JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); } catch(e) { console.error('DB load error:', e.message); }
  }
}
setInterval(saveDb, 10000);
process.on('exit', saveDb);
process.on('SIGINT', () => { saveDb(); process.exit(); });

const db = {
  _table(name) { return store[name] || []; },

  findOne(table, where) {
    return this._table(table).find(r => this._match(r, where)) || null;
  },
  findAll(table, where, opts = {}) {
    let rows = where ? this._table(table).filter(r => this._match(r, where)) : [...this._table(table)];
    if (opts.orderBy) {
      rows.sort((a, b) => {
        for (const [col, dir] of opts.orderBy) {
          const av = a[col] ?? '', bv = b[col] ?? '';
          const cmp = String(av).localeCompare(String(bv));
          if (cmp !== 0) return dir === 'DESC' ? -cmp : cmp;
        }
        return 0;
      });
    }
    if (opts.limit) rows = rows.slice(0, opts.limit);
    return rows;
  },
  insert(table, data) {
    if (!store[table]) store[table] = [];
    if (!store._counters[table]) store._counters[table] = 0;
    store._counters[table]++;
    const id = store._counters[table];
    const now = new Date().toISOString();
    const row = { id, created_at: now, updated_at: now, ...data };
    store[table].push(row);
    saveDb();
    return { id, lastInsertRowid: id };
  },
  update(table, where, data) {
    let count = 0;
    store[table] = this._table(table).map(r => {
      if (this._match(r, where)) { count++; return { ...r, ...data, updated_at: new Date().toISOString() }; }
      return r;
    });
    saveDb();
    return { changes: count };
  },
  delete(table, where) {
    const before = this._table(table).length;
    store[table] = this._table(table).filter(r => !this._match(r, where));
    saveDb();
    return { changes: before - store[table].length };
  },
  count(table, where) {
    return where ? this._table(table).filter(r => this._match(r, where)).length : this._table(table).length;
  },
  _match(row, where) {
    if (!where) return true;
    return Object.entries(where).every(([k, v]) => {
      if (v === null) return row[k] == null;
      if (typeof v === 'object' && v.$like) return String(row[k]||'').toLowerCase().includes(v.$like.replace(/%/g,'').toLowerCase());
      return row[k] == v;
    });
  }
};

function seed() {
  if (db.count('courses') > 0) return;

  // ── Courses ──────────────────────────────────
  db.insert('courses', { code:'NDIP-ICT', name:'National Diploma in ICT (Mainstream)', duration_years:3, is_active:1, aps_score:18,
    description:'A comprehensive 3-year qualification covering software development, networking, database management and systems analysis. Designed to produce well-rounded ICT professionals ready for the industry.',
    requirements: JSON.stringify({ matric:'National Senior Certificate or equivalent', subjects:['Mathematics (minimum 40%)','English (minimum 40%)','Physical Science or IT (recommended)'], aps:18, notes:'Students with N4/N5 qualifications may apply for exemptions.' }),
    subjects: JSON.stringify({ 'Year 1':['Introduction to Programming (Python/Java)','Computer Systems','Mathematics for ICT','Communication Skills','Networking Fundamentals'], 'Year 2':['Object-Oriented Programming','Database Management Systems','Systems Analysis & Design','Web Development','Operating Systems'], 'Year 3':['Software Engineering','Network Administration','Project Management','Work-Integrated Learning (WIL)','ICT Ethics & Law'] }),
    career_paths: JSON.stringify(['Software Developer','Systems Analyst','Database Administrator','Network Technician','IT Support Specialist','Web Developer'])
  });
  db.insert('courses', { code:'NDIP-ICT-ECP', name:'National Diploma in ICT – Extended Curriculum Programme (ECP)', duration_years:4, is_active:1, aps_score:15,
    description:'A 4-year extended programme with an additional foundational year. Designed for students who show potential but need extra preparation in mathematics and science.',
    requirements: JSON.stringify({ matric:'National Senior Certificate or equivalent', subjects:['Mathematics (minimum 30%)','English (minimum 40%)'], aps:15, notes:'Year 1 focuses on bridging and foundational concepts.' }),
    subjects: JSON.stringify({ 'Year 1 (Foundation)':['Foundation Mathematics','Foundation English','Introduction to Computers','Academic Literacy','Life Skills'], 'Year 2':['Introduction to Programming','Computer Systems','Mathematics for ICT','Communication Skills','Networking Fundamentals'], 'Year 3':['Object-Oriented Programming','Database Management Systems','Systems Analysis & Design','Web Development','Operating Systems'], 'Year 4':['Software Engineering','Network Administration','Project Management','Work-Integrated Learning (WIL)','ICT Ethics & Law'] }),
    career_paths: JSON.stringify(['Software Developer','Systems Analyst','Database Administrator','Network Technician','IT Support Specialist','Web Developer'])
  });
  db.insert('courses', { code:'ADV-DIP-ICT', name:'Advanced Diploma in Information and Communication Technology', duration_years:1, is_active:1, aps_score:null,
    description:'A 1-year post-diploma qualification for Diploma graduates who wish to deepen their expertise and prepare for professional registration or postgraduate study.',
    requirements: JSON.stringify({ minimum:'National Diploma in ICT or equivalent', average:'Minimum 60% average in the National Diploma', notes:'Applicants must have completed WIL. Selection is competitive based on academic merit.' }),
    subjects: JSON.stringify({ 'Year 1':['Advanced Software Development','Cloud Computing & DevOps','Cybersecurity Principles','Artificial Intelligence & Machine Learning','Research Methodology','Advanced Project (Capstone)'] }),
    career_paths: JSON.stringify(['Senior Software Engineer','Cloud Architect','Cybersecurity Analyst','Data Scientist','ICT Project Manager','Systems Architect','Postgraduate Studies'])
  });

  // ── IT Faculty / Lecturers (ICT Department only) ──
  db.insert('faculty', { name:'Mr X Piyose', title:'Mr', role:'Lecturer', subjects:JSON.stringify(['Internet Programming 1','Internet Programming 2','Web Development']), qualification:'MSc Computer Science', office:'J Block, Room J204', email:'xpiyose@mut.ac.za', phone:'031-907-7111 ext 204', is_active:1, is_hod:0 });
  db.insert('faculty', { name:'Ms N Dlamini', title:'Ms', role:'Head of Department (HOD)', subjects:JSON.stringify(['Software Engineering','Project Management','Research Methodology']), qualification:'PhD Information Technology', office:'J Block, Room J201', email:'ndlamini@mut.ac.za', phone:'031-907-7111 ext 201', is_active:1, is_hod:1 });
  db.insert('faculty', { name:'Mr S Mthembu', title:'Mr', role:'Senior Lecturer', subjects:JSON.stringify(['Database Management Systems','Systems Analysis & Design','Object-Oriented Programming']), qualification:'MTech Information Technology', office:'J Block, Room J205', email:'smthembu@mut.ac.za', phone:'031-907-7111 ext 205', is_active:1, is_hod:0 });
  db.insert('faculty', { name:'Ms T Khumalo', title:'Ms', role:'Lecturer', subjects:JSON.stringify(['Networking Fundamentals','Network Administration','Operating Systems']), qualification:'BSc Honours Computer Networks', office:'J Block, Room J206', email:'tkhumalo@mut.ac.za', phone:'031-907-7111 ext 206', is_active:1, is_hod:0 });
  db.insert('faculty', { name:'Mr P Ramdeyal', title:'Mr', role:'Lecturer / External Moderator', subjects:JSON.stringify(['Computer Systems','ICT Ethics & Law','Mathematics for ICT']), qualification:'MTech Computer Science', office:'J Block, Room J207', email:'pramdeyal@mut.ac.za', phone:'031-907-7111 ext 207', is_active:1, is_hod:0 });
  db.insert('faculty', { name:'Ms Z Nkosi', title:'Ms', role:'WIL Coordinator', subjects:JSON.stringify(['Work-Integrated Learning','Professional Practice','Communication Skills']), qualification:'BTech Information Technology', office:'J Block, Room J202', email:'znkosi@mut.ac.za', phone:'031-907-7111 ext 202', is_active:1, is_hod:0 });

  // ── Announcements ──────────────────────────────
  db.insert('announcements', { title:'Welcome to the 2025 Academic Year', content:'The ICT Department warmly welcomes all new and returning students. Orientation for first-year students will take place in Building C, Room 201 on Monday 10 February at 09:00. Please bring your student card and proof of registration.', category:'general', is_pinned:1, is_active:1 });
  db.insert('announcements', { title:'Registration Deadline Reminder', content:'All students must complete their module registrations by 28 February 2025. Late registrations will not be accepted. Contact the department office if you experience any issues.', category:'urgent', is_pinned:1, is_active:1 });
  db.insert('announcements', { title:'ICT Career Fair 2025', content:'The annual Career Fair takes place on 15 March 2025. Top companies including Accenture, EOH, and Dimension Data will attend. All students are encouraged to bring their CVs.', category:'career', is_pinned:0, is_active:1 });
  db.insert('announcements', { title:'WIL Placement Updates', content:'Final-year students seeking Work-Integrated Learning placements must submit CVs to the WIL coordinator (Ms Z Nkosi) by 1 March 2025. A list of approved companies is on the noticeboard.', category:'academic', is_pinned:0, is_active:1 });
  db.insert('announcements', { title:'Computer Lab Maintenance Notice', content:'The computer labs in J Block will be offline for maintenance from 14–16 February 2025. Students should make alternative arrangements during this period.', category:'general', is_pinned:0, is_active:1 });

  // ── FAQ ────────────────────────────────────────
  db.insert('faq', { question:'How do I apply for admission?', answer:'Applications are submitted through the MUT admissions office or at www.mut.ac.za/admissions. You need your ID, matric results, and proof of payment of the application fee. The ICT Department offers three programmes — check the Courses page for requirements.', category:'admissions', keywords:'apply,admission,register,how to apply', is_active:1 });
  db.insert('faq', { question:'What are the minimum requirements for the Mainstream Diploma?', answer:'You need a National Senior Certificate with Mathematics (40%+), English (40%+), and an APS score of at least 18. Physical Science or IT is recommended but not compulsory.', category:'admissions', keywords:'requirements,aps,mainstream,entry,marks', is_active:1 });
  db.insert('faq', { question:'What is the ECP programme?', answer:'ECP stands for Extended Curriculum Programme. It is a 4-year version of the 3-year Diploma that includes a foundational first year. It is ideal for students who narrowly missed the mainstream requirements but show strong potential.', category:'courses', keywords:'ecp,extended,4 year,foundation', is_active:1 });
  db.insert('faq', { question:'How do I book an appointment with a lecturer?', answer:'Log in as a student, go to the Appointments section, select a staff member from the list, choose an available time slot, and provide a reason for your visit. You will receive confirmation once the lecturer approves the booking.', category:'appointments', keywords:'book,appointment,lecturer,visit,meet', is_active:1 });
  db.insert('faq', { question:'Where is the ICT Department located?', answer:'The ICT Department is in J Block (Technology Building), Room J201, on the MUT main campus in Umlazi, Durban. The HOD office is Room J201 and lecturers are in Rooms J202–J207.', category:'general', keywords:'location,where,address,directions,find us', is_active:1 });
  db.insert('faq', { question:'Who handles financial aid and NSFAS?', answer:'Contact the MUT Financial Aid Office at financialaid@mut.ac.za or visit the Administration Building. The ICT Department does not handle NSFAS or fee queries directly.', category:'financial', keywords:'nsfas,financial aid,fees,funding,bursary', is_active:1 });
  db.insert('faq', { question:'How do I access my results on iEnabler?', answer:'Log in to the MUT student portal at ienabler.mut.ac.za using your student number and PIN. If you cannot access your results, contact the Registrar\'s office. The ICT Department cannot access individual student records.', category:'academic', keywords:'results,marks,ienabler,portal,grades', is_active:1 });
  db.insert('faq', { question:'What is Work-Integrated Learning (WIL)?', answer:'WIL is a mandatory 12-month period of industry-based learning that forms part of the final year of the National Diploma. Students are placed at approved companies to gain real-world experience. Contact Ms Z Nkosi (WIL Coordinator) for placements.', category:'academic', keywords:'wil,work integrated,placement,industry,training', is_active:1 });

  console.log('✅ Database seeded with full ICT department data');
}

function initDb() {
  loadDb();
  seed();
  return db;
}

module.exports = { initDb, getDb: () => db, db, saveDb };
