// ============================================
// Request Logger Middleware
// Logs every HTTP request: method, URL, status, time
// ============================================
const fs = require('fs');
const path = require('path');

const logDir = path.join(__dirname, '../logs');
if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });

function logger(req, res, next) {
  const start = Date.now();
  const timestamp = new Date().toISOString();

  res.on('finish', () => {
    const duration = Date.now() - start;
    const logLine = `[${timestamp}] ${req.method} ${req.originalUrl} → ${res.statusCode} (${duration}ms) | IP: ${req.ip}\n`;
    // Log to console
    console.log(`📋 ${req.method} ${req.originalUrl} → ${res.statusCode} (${duration}ms)`);
    // Append to log file
    fs.appendFile(path.join(logDir, 'access.log'), logLine, () => {});
  });
  next();
}

module.exports = logger;
