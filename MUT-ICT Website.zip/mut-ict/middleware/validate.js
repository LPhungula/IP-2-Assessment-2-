// ============================================
// Input Validation Middleware
// Validates and sanitizes incoming request data
// ============================================

function validateRegistration(req, res, next) {
  const { full_name, email, password, role } = req.body;
  const errors = [];

  if (!full_name || full_name.trim().length < 2)
    errors.push('Full name must be at least 2 characters.');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    errors.push('A valid email address is required.');
  if (!password || password.length < 6)
    errors.push('Password must be at least 6 characters.');
  if (!role || !['student','staff','guest'].includes(role))
    errors.push('Please select a valid role.');

  if (role === 'student' && !req.body.student_number)
    errors.push('Student number is required for student accounts.');
  if (role === 'staff' && !req.body.staff_number)
    errors.push('Staff number is required for staff accounts.');

  if (errors.length > 0) {
    return res.status(400).json({ error: errors[0], errors });
  }

  // Sanitize
  req.body.full_name = full_name.trim();
  req.body.email = email.trim().toLowerCase();
  next();
}

function validateAnnouncement(req, res, next) {
  const { title, content } = req.body;
  if (!title || title.trim().length < 3)
    return res.status(400).json({ error: 'Title must be at least 3 characters.' });
  if (!content || content.trim().length < 10)
    return res.status(400).json({ error: 'Content must be at least 10 characters.' });
  next();
}

function validateAppointment(req, res, next) {
  const { slot_id, reason } = req.body;
  if (!slot_id) return res.status(400).json({ error: 'Please select an appointment slot.' });
  if (!reason || reason.trim().length < 5)
    return res.status(400).json({ error: 'Please provide a reason (at least 5 characters).' });
  next();
}

function validateEnquiry(req, res, next) {
  const { name, email, subject, message } = req.body;
  if (!name || name.trim().length < 2)
    return res.status(400).json({ error: 'Name is required.' });
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ error: 'A valid email is required.' });
  if (!subject || subject.trim().length < 3)
    return res.status(400).json({ error: 'Subject is required.' });
  if (!message || message.trim().length < 10)
    return res.status(400).json({ error: 'Message must be at least 10 characters.' });
  next();
}

module.exports = { validateRegistration, validateAnnouncement, validateAppointment, validateEnquiry };
