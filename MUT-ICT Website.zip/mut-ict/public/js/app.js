// ============================================
// MUT ICT Department – Frontend Application
// Internet Programming 2 – ITPR300/ITNP300
// ============================================

// ── State ────────────────────────────────────
let currentUser = null;
let chatHistory = [];
let selectedStaff = null;
let selectedSlot = null;
let chatOpen = false;
let chatInitialized = false;
let allFaq = [];

// ── Init ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await checkAuth();
  initSearch();
  loadHomeData();
  updateRegForm(); // ensure register form starts in correct state
});

// ── Auth ──────────────────────────────────────
async function checkAuth() {
  try {
    const res = await fetch('/api/auth/me');
    if (res.ok) { const d = await res.json(); setUser(d.user); }
  } catch {}
}

function setUser(user) {
  currentUser = user;
  if (user) {
    document.getElementById('navAuth').style.display = 'none';
    document.getElementById('navUser').style.display = 'flex';
    document.getElementById('dropdownName').textContent = user.full_name;
    document.getElementById('dropdownRole').textContent = user.role;
    const av = document.getElementById('navAvatar');
    if (user.profile_picture) av.innerHTML = `<img src="${user.profile_picture}" alt="">`;
    else av.textContent = user.full_name[0].toUpperCase();
    if (['staff','admin'].includes(user.role)) document.getElementById('staffDashBtn').style.display = 'block';
  } else {
    document.getElementById('navAuth').style.display = 'flex';
    document.getElementById('navUser').style.display = 'none';
  }
}

function openAuth(tab = 'login') {
  document.getElementById('authModal').classList.add('active');
  switchAuthTab(tab);
  setTimeout(updateRegForm, 50);
}
function closeAuth() { document.getElementById('authModal').classList.remove('active'); }

function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach((t,i) => t.classList.toggle('active', (i===0&&tab==='login')||(i===1&&tab==='register')));
  document.getElementById('authLogin').classList.toggle('active', tab==='login');
  document.getElementById('authRegister').classList.toggle('active', tab==='register');
}

// ── Dynamic register form based on role ───────
function updateRegForm() {
  const role = document.querySelector('input[name="regRole"]:checked')?.value || 'student';
  const elems = {
    studentNum: document.getElementById('regStudentNumWrap'),
    staffNum:   document.getElementById('regStaffNumWrap'),
    course:     document.getElementById('regCourseWrap'),
    emailLabel: document.getElementById('regEmailLabel'),
    guestNote:  document.getElementById('regGuestNote')
  };
  // Hide all optional fields first
  elems.studentNum.style.display = 'none';
  elems.staffNum.style.display   = 'none';
  elems.course.style.display     = 'none';
  elems.guestNote.style.display  = 'none';

  if (role === 'student') {
    elems.studentNum.style.display = 'block';
    elems.course.style.display     = 'block';
    elems.emailLabel.textContent   = 'Email Address *';
  } else if (role === 'staff') {
    elems.staffNum.style.display   = 'block';
    elems.emailLabel.textContent   = 'Staff Email Address *';
  } else if (role === 'guest') {
    elems.guestNote.style.display  = 'block';
    elems.emailLabel.textContent   = 'Your Email Address * (used to identify your account)';
  }
}

async function login() {
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  if (!email || !password) return toast('Please enter your email and password.', 'error');
  try {
    const res = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password}) });
    const data = await res.json();
    if (!res.ok) return toast(data.error, 'error');
    setUser(data.user);
    closeAuth();
    toast(`Welcome back, ${data.user.full_name}! 👋`);
    if (['staff','admin'].includes(data.user.role)) navigateTo('staff-dashboard');
  } catch { toast('Login failed. Please try again.', 'error'); }
}

async function register() {
  const role = document.querySelector('input[name="regRole"]:checked')?.value || 'student';
  const full_name = document.getElementById('regName').value.trim();
  const email     = document.getElementById('regEmail').value.trim();
  const password  = document.getElementById('regPassword').value;
  let student_number = null, staff_number = null, course = null;

  // Role-specific validation
  if (!full_name) return toast('Please enter your full name.', 'error');
  if (role === 'student') {
    student_number = document.getElementById('regStudentNum').value.trim();
    if (!student_number) return toast('Please enter your student number.', 'error');
    course = document.getElementById('regCourse').value;
  }
  if (role === 'staff') {
    staff_number = document.getElementById('regStaffNum').value.trim();
    if (!staff_number) return toast('Please enter your staff number.', 'error');
  }
  if (!email) return toast('Please enter your email address.', 'error');
  if (!password || password.length < 6) return toast('Password must be at least 6 characters.', 'error');

  try {
    const res = await fetch('/api/auth/register', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({full_name,email,password,role,student_number,staff_number,course}) });
    const data = await res.json();
    if (!res.ok) return toast(data.error, 'error');
    setUser(data.user);
    closeAuth();
    toast(`Welcome to MUT ICT, ${data.user.full_name}! 🎓`);
  } catch { toast('Registration failed. Please try again.', 'error'); }
}

async function logout() {
  await fetch('/api/auth/logout', {method:'POST'});
  currentUser = null;
  setUser(null);
  navigateTo('home');
  toast('Logged out successfully.');
  document.getElementById('userDropdown').classList.remove('active');
}

function toggleUserDropdown(forceClose=false) {
  const d = document.getElementById('userDropdown');
  if (forceClose) { d.classList.remove('active'); return; }
  d.classList.toggle('active');
}
document.addEventListener('click', e => {
  if (!e.target.closest('.nav-user')) document.getElementById('userDropdown').classList.remove('active');
});

// ── Navigation ────────────────────────────────
function navigateTo(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const el = document.getElementById(`page-${page}`);
  if (!el) return;
  el.classList.add('active');
  window.scrollTo(0,0);
  // Update active nav link
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.toggle('active', a.dataset.page === page));
  // Load data
  const loaders = {
    courses: () => loadCourses('coursesGrid'),
    faculty: loadFaculty,
    announcements: () => loadAnnouncements('allAnnouncementsGrid'),
    faq: loadFaq,
    appointments: loadAppointments,
    profile: loadProfile,
    'staff-dashboard': loadStaffDashboard,
    timetable: () => {}
  };
  if (loaders[page]) loaders[page]();
}

// ── Home Data ─────────────────────────────────
async function loadHomeData() {
  loadCourses('homeCoursesGrid');
  loadAnnouncements('homeAnnouncementsGrid', 3);
  loadFacultyPreview();
}

// ── Courses ───────────────────────────────────
async function loadCourses(gridId) {
  const grid = document.getElementById(gridId);
  if (!grid) return;
  const res = await fetch('/api/courses');
  const courses = await res.json();
  const icons = {'NDIP-ICT':'💻','NDIP-ICT-ECP':'📖','ADV-DIP-ICT':'🎓'};
  grid.innerHTML = courses.map(c => `
    <div class="course-card${c.code==='ADV-DIP-ICT'?' maroon':''}" onclick='openCourse(${JSON.stringify(c).replace(/'/g,"&#39;")})'>
      <div class="course-card-header">
        <div class="course-icon">${icons[c.code]||'💻'}</div>
        <div>
          <div class="course-card-title">${c.name}</div>
          <span class="course-duration">⏱ ${c.duration_years} year${c.duration_years!==1?'s':''}</span>
        </div>
      </div>
      <div class="course-card-body"><p>${c.description.substring(0,130)}…</p></div>
      <div class="course-card-footer">
        <span class="aps-badge">${c.aps_score?`APS: <strong>${c.aps_score}+</strong>`:'Post-diploma entry'}</span>
        <button class="btn btn-blue btn-sm" onclick="event.stopPropagation();openCourse(${JSON.stringify(c).replace(/'/g,"&#39;")})">Details →</button>
      </div>
    </div>`).join('');
}

function openCourse(c) {
  document.getElementById('modalCode').textContent = c.code;
  document.getElementById('modalTitle').textContent = c.name;
  document.getElementById('modalDuration').textContent = `${c.duration_years} year${c.duration_years!==1?'s':''} programme`;
  document.getElementById('modalDesc').textContent = c.description;
  const reqs = typeof c.requirements==='string' ? JSON.parse(c.requirements) : c.requirements;
  let rhtml = '';
  if (reqs.matric||reqs.minimum) rhtml += `<div class="req-item">${reqs.matric||reqs.minimum}</div>`;
  if (reqs.subjects) reqs.subjects.forEach(s => rhtml += `<div class="req-item">${s}</div>`);
  if (reqs.aps) rhtml += `<div class="req-item">Minimum APS Score: <strong>${reqs.aps}</strong></div>`;
  if (reqs.average) rhtml += `<div class="req-item">${reqs.average}</div>`;
  if (reqs.notes) rhtml += `<p style="font-size:12px;color:var(--gray-400);margin-top:8px;">${reqs.notes}</p>`;
  document.getElementById('modalReqs').innerHTML = rhtml;
  const subs = typeof c.subjects==='string' ? JSON.parse(c.subjects) : c.subjects;
  document.getElementById('modalSubjects').innerHTML = Object.entries(subs).map(([yr,list]) =>
    `<div class="year-block"><div class="year-label">${yr}</div><div class="year-subjects">${list.map(s=>`<span class="subject-tag">${s}</span>`).join('')}</div></div>`).join('');
  const careers = typeof c.career_paths==='string' ? JSON.parse(c.career_paths) : c.career_paths;
  document.getElementById('modalCareers').innerHTML = careers.map(cp=>`<span class="career-tag">${cp}</span>`).join('');
  document.getElementById('courseModal').classList.add('active');
}
function openCourseByCode(code) { fetch(`/api/courses/${code}`).then(r=>r.json()).then(openCourse); }
function closeCourseModal() { document.getElementById('courseModal').classList.remove('active'); }

// ── Faculty ───────────────────────────────────
async function loadFaculty() {
  const grid = document.getElementById('facultyGrid');
  if (!grid) return;
  const res = await fetch('/api/faculty');
  const faculty = await res.json();
  grid.innerHTML = faculty.map(f => facultyCard(f)).join('');
}

async function loadFacultyPreview() {
  const container = document.getElementById('facultyPreview');
  if (!container) return;
  const res = await fetch('/api/faculty');
  const faculty = await res.json();
  container.innerHTML = faculty.map(f => `
    <div class="faculty-mini" onclick='openFacultyModal(${JSON.stringify(f).replace(/'/g,"&#39;")})'>
      <div class="mini-avatar">${f.name.split(' ').filter(w=>w.match(/^[A-Z]/)).map(w=>w[0]).slice(0,2).join('')||'?'}</div>
      <div class="mini-name">${f.name}</div>
      <div class="mini-role">${f.role}</div>
    </div>`).join('');
}

function facultyCard(f) {
  const initials = f.name.split(' ').filter(w=>w.match(/^[A-Z]/)).map(w=>w[0]).slice(0,2).join('') || '?';
  return `
    <div class="faculty-card" onclick='openFacultyModal(${JSON.stringify(f).replace(/'/g,"&#39;")})'>
      <div class="faculty-card-top">
        <div class="faculty-avatar">${initials}</div>
        <div>
          <div class="faculty-name">${f.name}</div>
          <div class="faculty-role">${f.role}</div>
          ${f.is_hod ? '<span class="faculty-hod-badge">HOD</span>' : ''}
        </div>
      </div>
      <div class="faculty-card-body">
        <div style="font-size:12px;color:var(--gray-500);">📚 Subjects taught:</div>
        <div class="faculty-subjects">${(Array.isArray(f.subjects)?f.subjects:[]).slice(0,3).map(s=>`<span class="faculty-subject">${s}</span>`).join('')}${(Array.isArray(f.subjects)?f.subjects:[]).length>3?`<span class="faculty-subject">+${f.subjects.length-3} more</span>`:''}</div>
        <div class="faculty-contact" style="margin-top:12px;">📧 ${f.email} &nbsp;|&nbsp; 📍 ${f.office}</div>
      </div>
    </div>`;
}

function openFacultyModal(f) {
  document.getElementById('fmTitle').textContent = f.qualification || 'ICT Department';
  document.getElementById('fmName').textContent = f.name;
  document.getElementById('fmRole').textContent = f.role;
  const subs = Array.isArray(f.subjects) ? f.subjects : JSON.parse(f.subjects||'[]');
  document.getElementById('fmSubjects').innerHTML = subs.map(s=>`<span class="subject-tag">${s}</span>`).join('');
  document.getElementById('fmOffice').textContent = `📍 ${f.office}`;
  document.getElementById('fmEmail').textContent = `✉️ ${f.email}`;
  document.getElementById('fmPhone').textContent = `📞 ${f.phone}`;
  document.getElementById('fmQual').textContent = `🎓 ${f.qualification}`;
  document.getElementById('facultyModal').classList.add('active');
}
function closeFacultyModal() { document.getElementById('facultyModal').classList.remove('active'); }

// ── Announcements ─────────────────────────────
async function loadAnnouncements(gridId, limit) {
  const grid = document.getElementById(gridId);
  if (!grid) return;
  const res = await fetch('/api/announcements');
  let anns = await res.json();
  if (limit) anns = anns.slice(0,limit);

  // Show staff controls if staff/admin
  const staffCtrl = document.getElementById('staffAnnControls');
  if (staffCtrl && currentUser && ['staff','admin'].includes(currentUser.role)) staffCtrl.style.display = 'block';

  grid.innerHTML = anns.map(a => `
    <div class="announcement-card ${a.is_pinned?'pinned':''}">
      <span class="ann-category ${a.category}">${a.category}</span>
      <div class="ann-content">
        <h4>${a.title}</h4>
        <p>${a.content}</p>
        <div class="ann-date">📅 ${new Date(a.created_at).toLocaleDateString('en-ZA',{day:'numeric',month:'long',year:'numeric'})}</div>
        ${currentUser&&['staff','admin'].includes(currentUser.role)?`<button class="btn btn-sm" style="margin-top:8px;background:#fce8e6;color:var(--danger);" onclick="deleteAnnouncement(${a.id})">🗑 Delete</button>`:''}
      </div>
    </div>`).join('') || '<p style="color:var(--gray-400);text-align:center;padding:30px;">No announcements yet.</p>';
}

function openNewAnnouncementForm() {
  document.getElementById('newAnnForm').style.display = 'block';
  document.getElementById('newAnnForm').scrollIntoView({behavior:'smooth'});
}
function closeAnnForm() { document.getElementById('newAnnForm').style.display = 'none'; }

async function submitAnnouncement() {
  const title = document.getElementById('annTitle').value.trim();
  const content = document.getElementById('annContent').value.trim();
  const category = document.getElementById('annCategory').value;
  const is_pinned = document.getElementById('annPinned').value;
  if (!title||!content) return toast('Title and content are required.','error');
  const res = await fetch('/api/announcements', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,content,category,is_pinned})});
  const data = await res.json();
  if (!res.ok) return toast(data.error,'error');
  toast('Announcement posted! 📢');
  closeAnnForm();
  loadAnnouncements('allAnnouncementsGrid');
}

async function deleteAnnouncement(id) {
  if (!confirm('Delete this announcement?')) return;
  await fetch(`/api/announcements/${id}`,{method:'DELETE'});
  toast('Announcement deleted.');
  loadAnnouncements('allAnnouncementsGrid');
}

// ── FAQ ───────────────────────────────────────
async function loadFaq() {
  const res = await fetch('/api/faq');
  allFaq = await res.json();
  renderFaq(allFaq);
}

function renderFaq(items) {
  const list = document.getElementById('faqList');
  if (!list) return;
  list.innerHTML = items.map(f => `
    <div class="faq-item" onclick="toggleFaq(this)">
      <div class="faq-question">
        <span>${f.question}</span>
        <span class="faq-cat">${f.category}</span>
      </div>
      <div class="faq-answer">${f.answer}</div>
    </div>`).join('') || '<p style="color:var(--gray-400);text-align:center;padding:30px;">No FAQs match your search.</p>';
}

function toggleFaq(el) { el.classList.toggle('open'); }

function filterFaq(q) {
  if (!q.trim()) return renderFaq(allFaq);
  const ql = q.toLowerCase();
  renderFaq(allFaq.filter(f => f.question.toLowerCase().includes(ql) || f.answer.toLowerCase().includes(ql) || (f.keywords||'').toLowerCase().includes(ql)));
}

// ── Enquiry ───────────────────────────────────
async function submitEnquiry() {
  const name    = document.getElementById('enqName').value.trim();
  const email   = document.getElementById('enqEmail').value.trim();
  const subject = document.getElementById('enqSubject').value.trim();
  const message = document.getElementById('enqMessage').value.trim();
  const course  = document.getElementById('enqCourse').value;
  if (!name)    return toast('Please enter your name.','error');
  if (!email)   return toast('Please enter your email.','error');
  if (!subject) return toast('Please enter a subject.','error');
  if (message.length<10) return toast('Please write a more detailed message.','error');
  const res = await fetch('/api/enquiries',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,email,subject,message,course})});
  const data = await res.json();
  if (!res.ok) return toast(data.error,'error');
  document.getElementById('enquiryFormCard').style.display = 'none';
  document.getElementById('enquirySuccess').style.display = 'block';
  // Clear form
  ['enqName','enqEmail','enqSubject','enqMessage'].forEach(id=>document.getElementById(id).value='');
}

// ── Smart Search ──────────────────────────────
function initSearch() {
  const input = document.getElementById('globalSearch');
  const dropdown = document.getElementById('searchDropdown');
  let debounce;
  input.addEventListener('input', () => {
    clearTimeout(debounce);
    debounce = setTimeout(async () => {
      const q = input.value.trim();
      if (q.length < 2) { dropdown.classList.remove('active'); return; }
      const res = await fetch(`/api/search/suggest?q=${encodeURIComponent(q)}`);
      const results = await res.json();
      if (!results.length) { dropdown.classList.remove('active'); return; }
      dropdown.innerHTML = results.map(r => `
        <div class="search-item" onclick="handleSearch('${r.text.replace(/'/g,"\\'")}')">
          <span class="search-item-type ${r.type}">${r.type}</span>
          <span class="search-item-text">${r.text}</span>
        </div>`).join('');
      dropdown.classList.add('active');
    }, 250);
  });
  document.addEventListener('click', e => { if(!e.target.closest('.nav-search')) dropdown.classList.remove('active'); });
}

function handleSearch(query) {
  document.getElementById('globalSearch').value = query;
  document.getElementById('searchDropdown').classList.remove('active');
  if (!chatOpen) toggleChat();
  setTimeout(() => { document.getElementById('chatInput').value = query; sendChat(); }, 300);
}

// ── Timetable ─────────────────────────────────
async function loadTimetable() {
  const course = document.getElementById('ttCourse').value;
  const year = document.getElementById('ttYear').value;
  const semester = document.getElementById('ttSemester').value;
  const container = document.getElementById('timetableContainer');
  if (!course) return toast('Please select a course.','warning');
  container.innerHTML = `<div class="loading-spinner"><div class="spinner"></div></div>`;
  const params = new URLSearchParams();
  if (year) params.set('year',year);
  if (semester) params.set('semester',semester);
  const res = await fetch(`/api/timetable/${course}?${params}`);
  const rows = await res.json();
  if (!rows.length) {
    container.innerHTML = '<p style="text-align:center;color:var(--gray-400);padding:40px;">No timetable data found. Please contact the department office: ict@mut.ac.za</p>';
    return;
  }
  container.innerHTML = `<div class="timetable-wrap"><table class="timetable">
    <thead><tr><th>Day</th><th>Time</th><th>Subject</th><th>Venue</th><th>Lecturer</th></tr></thead>
    <tbody>${rows.map(r=>`<tr><td>${r.day}</td><td>${r.time_start}–${r.time_end}</td><td class="subject-cell">${r.subject}</td><td>${r.venue||'–'}</td><td>${r.lecturer||'–'}</td></tr>`).join('')}</tbody>
  </table></div>`;
}

// ── Appointments ──────────────────────────────
async function loadAppointments() {
  document.getElementById('apptGuestNotice').style.display = currentUser ? 'none' : 'block';
  const res = await fetch('/api/appointments/staff');
  const staff = await res.json();
  const list = document.getElementById('staffList');
  list.innerHTML = staff.length ? staff.map(s=>`
    <div class="staff-card" onclick="selectStaff(${JSON.stringify(s).replace(/"/g,'&quot;')})" id="staff-${s.id}">
      <div class="staff-avatar">${s.full_name[0]}</div>
      <div class="staff-info"><h4>${s.full_name}</h4><div class="staff-dept">${s.department||'ICT Department'}</div></div>
    </div>`).join('') : '<p style="color:var(--gray-400);">No staff members available.</p>';
  if (currentUser?.role==='student') { document.getElementById('myAppointmentsSection').style.display='block'; loadMyAppointments(); }
}

async function selectStaff(staff) {
  selectedStaff = staff;
  document.querySelectorAll('.staff-card').forEach(c=>c.classList.remove('selected'));
  document.getElementById(`staff-${staff.id}`)?.classList.add('selected');
  const panel = document.getElementById('slotPanel');
  panel.innerHTML = `<h3 style="margin-bottom:16px;font-size:15px;color:var(--gray-600);">Slots for ${staff.full_name}</h3><div class="loading-spinner"><div class="spinner"></div></div>`;
  const res = await fetch(`/api/appointments/slots/${staff.id}`);
  const slots = await res.json();
  const available = slots.filter(s=>s.booked===0);
  if (!available.length) { panel.innerHTML += '<p style="color:var(--gray-400);">No available slots. Check back later.</p>'; return; }
  panel.innerHTML = `<h3 style="margin-bottom:16px;font-size:15px;color:var(--gray-600);">Available slots with ${staff.full_name}</h3>
    <div class="slot-grid">${available.map(s=>`
      <div class="slot-item" onclick="bookSlot(${JSON.stringify(s).replace(/"/g,'&quot;')})">
        <div><div class="slot-time">🕐 ${s.time_start}–${s.time_end}</div>
        <div class="slot-date">📅 ${new Date(s.date).toLocaleDateString('en-ZA',{weekday:'long',day:'numeric',month:'long'})}</div>
        ${s.notes?`<div class="slot-date">📝 ${s.notes}</div>`:''}</div>
        <button class="btn btn-blue btn-sm">Book</button>
      </div>`).join('')}</div>`;
}

function bookSlot(slot) {
  if (!currentUser) return openAuth('login');
  if (currentUser.role==='guest') { toast('Please create a student account to book appointments.','warning'); return openAuth('register'); }
  selectedSlot = slot;
  document.getElementById('bookingDetails').innerHTML = `<strong>Staff:</strong> ${selectedStaff?.full_name}<br><strong>Date:</strong> ${new Date(slot.date).toLocaleDateString('en-ZA',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}<br><strong>Time:</strong> ${slot.time_start}–${slot.time_end}`;
  document.getElementById('bookingModal').classList.add('active');
}

async function confirmBooking() {
  const reason = document.getElementById('bookingReason').value.trim();
  if (!reason) return toast('Please provide a reason for the appointment.','error');
  const res = await fetch('/api/appointments/book',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({slot_id:selectedSlot.id,reason})});
  const data = await res.json();
  if (!res.ok) return toast(data.error,'error');
  closeBookingModal();
  toast('Appointment booked successfully! 📅');
  selectStaff(selectedStaff);
  loadMyAppointments();
}
function closeBookingModal() { document.getElementById('bookingModal').classList.remove('active'); }

async function loadMyAppointments() {
  const list = document.getElementById('myAppointmentsList');
  const res = await fetch('/api/appointments/my');
  const appts = await res.json();
  list.innerHTML = appts.length ? `<div style="display:flex;flex-direction:column;gap:12px;">${appts.map(a=>`
    <div class="announcement-card">
      <span class="ann-category ${a.status==='confirmed'?'academic':a.status==='cancelled'?'urgent':'general'}">${a.status}</span>
      <div class="ann-content"><h4>With ${a.staff_name||'Staff'}</h4><p>${a.reason}</p>
      <div class="ann-date">📅 ${a.date?new Date(a.date).toLocaleDateString('en-ZA'):''} at ${a.time_start||''}</div></div>
    </div>`).join('')}</div>` : '<p style="color:var(--gray-400);">No appointments booked yet.</p>';
}

// ── Profile ───────────────────────────────────
async function loadProfile() {
  if (!currentUser) return openAuth('login');
  const res = await fetch('/api/profile');
  const user = await res.json();
  document.getElementById('profileName').textContent = user.full_name;
  document.getElementById('profileRoleBadge').textContent = user.role;
  const av = document.getElementById('profileAvatar');
  if (user.profile_picture) av.innerHTML = `<img src="${user.profile_picture}" alt="">`;
  else av.textContent = user.full_name[0].toUpperCase();
  document.getElementById('profileInfoGrid').innerHTML = `
    <div class="info-row"><div class="info-label">Email</div><div class="info-value">${user.email}</div></div>
    ${user.student_number?`<div class="info-row"><div class="info-label">Student No.</div><div class="info-value">${user.student_number}</div></div>`:''}
    ${user.staff_number?`<div class="info-row"><div class="info-label">Staff No.</div><div class="info-value">${user.staff_number}</div></div>`:''}
    ${user.course?`<div class="info-row"><div class="info-label">Course</div><div class="info-value">${user.course}</div></div>`:''}
    <div class="info-row"><div class="info-label">Member since</div><div class="info-value">${new Date(user.created_at).toLocaleDateString('en-ZA')}</div></div>`;
  document.getElementById('editName').value  = user.full_name||'';
  document.getElementById('editPhone').value = user.phone||'';
  document.getElementById('editBio').value   = user.bio||'';
  if (user.role==='student') { document.getElementById('editCourseWrap').style.display='block'; document.getElementById('editCourse').value=user.course||''; }
}

async function saveProfile() {
  const body = { full_name:document.getElementById('editName').value.trim(), phone:document.getElementById('editPhone').value.trim(), bio:document.getElementById('editBio').value.trim(), course:document.getElementById('editCourse')?.value };
  const res = await fetch('/api/profile',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data = await res.json();
  if (!res.ok) return toast(data.error,'error');
  currentUser = data.user; setUser(data.user);
  toast('Profile updated! ✅'); loadProfile();
}

async function uploadProfilePicture(input) {
  const file = input.files[0]; if (!file) return;
  const formData = new FormData(); formData.append('image',file);
  const res = await fetch('/api/upload/profile-picture',{method:'POST',body:formData});
  const data = await res.json();
  if (!res.ok) return toast(data.error,'error');
  toast('Profile picture updated! 📷'); loadProfile();
}

async function processImage() {
  const file = document.getElementById('generalImageInput').files[0];
  if (!file) return toast('Please select an image first.','warning');
  const formData = new FormData(); formData.append('image',file);
  const width=document.getElementById('imgWidth').value, quality=document.getElementById('imgQuality').value, rotate=document.getElementById('imgRotate').value, grayscale=document.getElementById('imgGrayscale').checked;
  if (width) formData.append('width',width); if (quality) formData.append('quality',quality); if (rotate) formData.append('rotate',rotate); formData.append('grayscale',grayscale?'true':'false');
  const res = await fetch('/api/upload/image',{method:'POST',body:formData});
  const data = await res.json();
  if (!res.ok) return toast(data.error,'error');
  document.getElementById('imagePreview').innerHTML = `<p style="font-size:13px;color:var(--gray-600);margin-bottom:8px;">✅ Processed:</p><img src="${data.url}" style="max-width:100%;border-radius:var(--radius-md);"><p style="font-size:12px;color:var(--gray-400);margin-top:6px;">${data.url}</p>`;
  toast('Image processed! ⚙️');
}

// ── Staff Dashboard ───────────────────────────
function switchDashTab(tab, btn) {
  document.querySelectorAll('.dash-panel').forEach(p=>p.style.display='none');
  document.querySelectorAll('.dash-tab').forEach(b=>b.classList.remove('active'));
  document.getElementById(`dash-${tab}`).style.display='block';
  btn.classList.add('active');
  if (tab==='bookings') loadStaffBookings();
  if (tab==='announcements') loadDashAnnouncements();
  if (tab==='enquiries') loadEnquiries();
  // Timetable tab doesn't auto-load — staff selects a course first
}

async function loadStaffDashboard() {
  if (!currentUser||!['staff','admin'].includes(currentUser.role)) return;
}

async function loadStaffBookings() {
  const res = await fetch('/api/appointments/bookings');
  const bookings = await res.json();
  document.getElementById('staffBookingsList').innerHTML = bookings.length ? `<div style="display:flex;flex-direction:column;gap:12px;">${bookings.map(b=>`
    <div class="announcement-card">
      <span class="ann-category ${b.status==='confirmed'?'academic':b.status==='pending'?'general':'urgent'}">${b.status}</span>
      <div class="ann-content">
        <h4>${b.student_name} (${b.student_number||'N/A'})</h4>
        <p>${b.reason}</p>
        <div class="ann-date">📅 ${b.date} at ${b.time_start} | ✉️ ${b.student_email}</div>
        ${b.status==='pending'?`<div style="display:flex;gap:8px;margin-top:10px;">
          <button class="btn btn-blue btn-sm" onclick="updateAppt(${b.id},'confirmed')">✅ Confirm</button>
          <button class="btn btn-sm" style="background:#fce8e6;color:var(--danger);" onclick="updateAppt(${b.id},'cancelled')">✕ Cancel</button>
        </div>`:''}
      </div>
    </div>`).join('')}</div>` : '<p style="color:var(--gray-400);">No bookings yet.</p>';
}

async function updateAppt(id,status) {
  await fetch(`/api/appointments/${id}/status`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});
  toast(`Appointment ${status}. ✅`); loadStaffBookings();
}

async function addSlot() {
  const date=document.getElementById('slotDate').value, time_start=document.getElementById('slotStart').value, time_end=document.getElementById('slotEnd').value, notes=document.getElementById('slotNotes').value;
  if (!date||!time_start||!time_end) return toast('Please fill in date and times.','error');
  const res = await fetch('/api/appointments/slots',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({date,time_start,time_end,notes})});
  if (res.ok) toast('Slot added! ✅');
}

async function loadDashAnnouncements() {
  const res = await fetch('/api/announcements');
  const anns = await res.json();
  document.getElementById('dashAnnList').innerHTML = `<div style="display:flex;flex-direction:column;gap:10px;">${anns.slice(0,5).map(a=>`
    <div class="announcement-card ${a.is_pinned?'pinned':''}">
      <span class="ann-category ${a.category}">${a.category}</span>
      <div class="ann-content"><h4>${a.title}</h4><div class="ann-date">${new Date(a.created_at).toLocaleDateString('en-ZA')}</div>
      <button class="btn btn-sm" style="margin-top:6px;background:#fce8e6;color:var(--danger);" onclick="deleteAnnouncement(${a.id});loadDashAnnouncements()">🗑 Delete</button></div>
    </div>`).join('')}</div>`;
}

async function postDashAnnouncement() {
  const title=document.getElementById('dashAnnTitle').value.trim(), content=document.getElementById('dashAnnContent').value.trim(), category=document.getElementById('dashAnnCat').value, is_pinned=document.getElementById('dashAnnPin').value;
  if (!title||!content) return toast('Title and content required.','error');
  const res = await fetch('/api/announcements',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,content,category,is_pinned})});
  if (res.ok) { toast('Posted! 📢'); loadDashAnnouncements(); document.getElementById('dashAnnTitle').value=''; document.getElementById('dashAnnContent').value=''; }
}

async function loadEnquiries() {
  const res = await fetch('/api/enquiries');
  if (!res.ok) return;
  const enquiries = await res.json();
  document.getElementById('dashEnquiriesList').innerHTML = enquiries.length ? `<div style="display:flex;flex-direction:column;gap:12px;">${enquiries.map(e=>`
    <div class="announcement-card">
      <span class="status-${e.status||'new'}">${e.status||'new'}</span>
      <div class="ann-content">
        <h4>${e.subject} – <span style="font-weight:400;">${e.name}</span></h4>
        <p>${e.message}</p>
        <div class="ann-date">✉️ ${e.email} ${e.course?`| Course: ${e.course}`:''} | ${new Date(e.created_at).toLocaleDateString('en-ZA')}</div>
        <div style="display:flex;gap:8px;margin-top:8px;">
          <button class="btn btn-sm" style="background:#fef7e0;color:var(--warning);" onclick="updateEnquiry(${e.id},'in-progress')">In Progress</button>
          <button class="btn btn-sm" style="background:#e8f5e9;color:var(--success);" onclick="updateEnquiry(${e.id},'resolved')">Resolved</button>
        </div>
      </div>
    </div>`).join('')}</div>` : '<p style="color:var(--gray-400);">No enquiries yet.</p>';
}

async function updateEnquiry(id,status) {
  await fetch(`/api/enquiries/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});
  toast(`Marked as ${status}`); loadEnquiries();
}

// ── Chatbot ───────────────────────────────────
function toggleChat() {
  chatOpen = !chatOpen;
  document.getElementById('chatWindow').classList.toggle('open',chatOpen);
  document.getElementById('chatBadge').style.display='none';
  if (chatOpen&&!chatInitialized) {
    chatInitialized=true;
    addBotMsg("Hi! 👋 I'm **Lexi**, your MUT ICT Department assistant.\n\nI can help with courses, admission requirements, appointments, and more. What would you like to know?");
    showChatSuggestions(['What courses are offered?','How do I apply?','ECP programme info','Book an appointment']);
  }
}

function showChatSuggestions(items) {
  document.getElementById('chatSuggestions').innerHTML = items.map(i=>`<button class="chat-suggestion" onclick="sendChatMsg('${i}')">${i}</button>`).join('');
}

function addBotMsg(text) {
  const msgs = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className='chat-msg bot';
  div.innerHTML=`<div class="chat-bubble-text">${text.replace(/\n/g,'<br>').replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>')}</div><div class="chat-msg-time">${now()}</div>`;
  msgs.appendChild(div); msgs.scrollTop=msgs.scrollHeight;
  chatHistory.push({role:'assistant',content:text});
}

function addUserMsg(text) {
  const msgs = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className='chat-msg user';
  div.innerHTML=`<div class="chat-bubble-text">${text}</div><div class="chat-msg-time">${now()}</div>`;
  msgs.appendChild(div); msgs.scrollTop=msgs.scrollHeight;
  chatHistory.push({role:'user',content:text});
}

function showTyping() {
  const msgs=document.getElementById('chatMessages');
  const div=document.createElement('div'); div.id='typingIndicator'; div.className='chat-typing';
  div.innerHTML='<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';
  msgs.appendChild(div); msgs.scrollTop=msgs.scrollHeight;
}
function hideTyping() { document.getElementById('typingIndicator')?.remove(); }

function sendChatMsg(text) { document.getElementById('chatInput').value=text; sendChat(); }

async function sendChat() {
  const input=document.getElementById('chatInput');
  const text=input.value.trim(); if (!text) return;
  input.value=''; document.getElementById('chatSuggestions').innerHTML='';
  addUserMsg(text); showTyping();
  try {
    const res=await fetch('/api/chat/message',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,history:chatHistory.slice(-10)})});
    const data=await res.json(); hideTyping(); addBotMsg(data.reply);
    const t=text.toLowerCase();
    if (t.includes('appoint')) showChatSuggestions(['Book appointment','Who can I see?']);
    else if (t.includes('course')||t.includes('diploma')||t.includes('ecp')) showChatSuggestions(['View courses','Requirements?','ECP vs Mainstream?']);
    else showChatSuggestions(['Tell me more','Contact department','FAQ']);
  } catch { hideTyping(); addBotMsg("Sorry, I'm having trouble right now. Please try again!"); }
}

function now() { return new Date().toLocaleTimeString('en-ZA',{hour:'2-digit',minute:'2-digit'}); }

// ── Toast ─────────────────────────────────────
function toast(msg,type='success') {
  const c=document.getElementById('toast-container');
  const t=document.createElement('div'); t.className=`toast ${type}`; t.textContent=msg;
  c.appendChild(t); setTimeout(()=>t.remove(),4000);
}

// ── Timetable Management (Staff Dashboard) ────────────────────

// Add a new timetable entry from the staff dashboard form
async function addTimetableEntry() {
  const course_code   = document.getElementById('ttAddCourse').value;
  const year_of_study = document.getElementById('ttAddYear').value;
  const day           = document.getElementById('ttAddDay').value;
  const semester      = document.getElementById('ttAddSemester').value;
  const time_start    = document.getElementById('ttAddStart').value;
  const time_end      = document.getElementById('ttAddEnd').value;
  const subject       = document.getElementById('ttAddSubject').value.trim();
  const venue         = document.getElementById('ttAddVenue').value.trim();
  const lecturer      = document.getElementById('ttAddLecturer').value.trim();

  // Validate required fields before sending to server
  if (!course_code) return toast('Please select a course.', 'error');
  if (!time_start || !time_end) return toast('Please enter start and end time.', 'error');
  if (!subject) return toast('Please enter the subject name.', 'error');
  if (time_start >= time_end) return toast('End time must be after start time.', 'error');

  try {
    const res = await fetch('/api/timetable', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ course_code, year_of_study, day, semester, time_start, time_end, subject, venue, lecturer })
    });
    const data = await res.json();
    if (!res.ok) return toast(data.error, 'error');

    toast(`✅ "${subject}" added to timetable!`);

    // Clear the form fields ready for next entry
    document.getElementById('ttAddSubject').value = '';
    document.getElementById('ttAddVenue').value   = '';
    document.getElementById('ttAddLecturer').value = '';
    document.getElementById('ttAddStart').value   = '';
    document.getElementById('ttAddEnd').value     = '';

    // Refresh the management table if it's currently showing entries
    const manageCourse = document.getElementById('ttManageCourse').value;
    if (manageCourse) loadManageTimetable();

  } catch (err) {
    toast('Failed to add entry. Please try again.', 'error');
  }
}

// Load existing timetable entries for staff to view and delete
async function loadManageTimetable() {
  const course = document.getElementById('ttManageCourse').value;
  const year   = document.getElementById('ttManageYear').value;
  const list   = document.getElementById('dashTimetableList');

  if (!course) return toast('Please select a course to view.', 'warning');

  list.innerHTML = `<div class="loading-spinner"><div class="spinner"></div> Loading entries…</div>`;

  const params = new URLSearchParams();
  if (year) params.set('year', year);

  try {
    const res = await fetch(`/api/timetable/${course}?${params}`);
    const rows = await res.json();

    if (!rows.length) {
      list.innerHTML = '<p style="color:var(--gray-400); text-align:center; padding:30px;">No timetable entries found. Use the form above to add entries.</p>';
      return;
    }

    // Group entries by day for a cleaner display
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const grouped = {};
    days.forEach(d => { grouped[d] = rows.filter(r => r.day === d); });

    let html = `<p style="font-size:13px; color:var(--gray-500); margin-bottom:16px;">Showing ${rows.length} entr${rows.length === 1 ? 'y' : 'ies'} — click 🗑 to delete an entry.</p>`;

    days.forEach(day => {
      if (!grouped[day].length) return;
      html += `<div style="margin-bottom:20px;">
        <div style="font-size:12px; font-weight:700; color:var(--mut-blue); text-transform:uppercase; letter-spacing:1px; margin-bottom:8px; padding:6px 12px; background:#e8eef8; border-radius:var(--radius-sm);">${day}</div>
        <div class="timetable-wrap">
          <table class="timetable">
            <thead><tr><th>Time</th><th>Subject</th><th>Venue</th><th>Lecturer</th><th>Sem</th><th>Year</th><th>Action</th></tr></thead>
            <tbody>
              ${grouped[day].map(r => `
                <tr>
                  <td style="white-space:nowrap;">${r.time_start} – ${r.time_end}</td>
                  <td class="subject-cell">${r.subject}</td>
                  <td>${r.venue || '–'}</td>
                  <td>${r.lecturer || '–'}</td>
                  <td>${r.semester}</td>
                  <td>Year ${r.year_of_study}</td>
                  <td>
                    <button class="btn btn-sm" 
                      style="background:#fce8e6; color:var(--danger); padding:4px 10px;"
                      onclick="deleteTimetableEntry(${r.id}, '${r.subject}')">
                      🗑 Delete
                    </button>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
    });

    list.innerHTML = html;

  } catch (err) {
    list.innerHTML = '<p style="color:var(--danger); text-align:center; padding:20px;">Failed to load timetable entries.</p>';
  }
}

// Delete a timetable entry with confirmation
async function deleteTimetableEntry(id, subject) {
  if (!confirm(`Delete "${subject}" from the timetable? This cannot be undone.`)) return;

  try {
    const res = await fetch(`/api/timetable/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) return toast(data.error, 'error');
    toast(`🗑 "${subject}" removed from timetable.`);
    loadManageTimetable(); // Refresh the list
  } catch (err) {
    toast('Failed to delete entry. Please try again.', 'error');
  }
}
